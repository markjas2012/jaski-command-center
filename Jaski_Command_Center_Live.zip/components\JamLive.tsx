"use client";

import { useEffect, useState } from "react";
import styles from "./JamLive.module.css";

type Story = {
  title: string;
  source: string;
  href: string;
  date?: string;
  band?: string;
  priority?: boolean;
};

type JamFeed = {
  updatedAt: string;
  stories: Story[];
};

const fallback: Story[] = [
  {
    title: "Latest jam-band news and tour announcements",
    source: "JamBase",
    href: "https://www.jambase.com/",
  },
  {
    title: "Music news, interviews and new releases",
    source: "Relix",
    href: "https://relix.com/",
  },
  {
    title: "Live music coverage and notable shows",
    source: "Live For Live Music",
    href: "https://liveforlivemusic.com/",
  },
];

export default function JamLive() {
  const [feed, setFeed] = useState<JamFeed | null>(null);

  useEffect(() => {
    let active = true;

    fetch("/api/jam-feed", { cache: "no-store" })
      .then((r) => (r.ok ? r.json() : Promise.reject()))
      .then((data) => active && setFeed(data))
      .catch(() => active && setFeed({ updatedAt: "", stories: fallback }));

    return () => {
      active = false;
    };
  }, []);

  const stories = feed?.stories?.length ? feed.stories.slice(0, 6) : fallback;

  return (
    <section className={styles.wrap}>
      <div className={styles.heading}>
        <div>
          <p>NOW PLAYING</p>
          <h2>What’s happening in the Jam Room.</h2>
          <small>Favorites first, then the best current stories from the wider jam scene.</small>
        </div>
        <span>{feed?.updatedAt ? `Updated ${feed.updatedAt}` : "Current links"}</span>
      </div>

      <div className={styles.grid}>
        {stories.map((story) => (
          <a
            key={story.href + story.title}
            className={`${styles.story} ${story.priority ? styles.priority : ""}`}
            href={story.href}
            target="_blank"
            rel="noreferrer"
          >
            <div className={styles.storyTop}>
              <div className={styles.tags}>
                <span className={styles.source}>{story.source}</span>
                {story.band ? <span className={styles.band}>{story.band}</span> : null}
              </div>
              <small>{story.date || "Latest"}</small>
            </div>

            <h3>{story.title}</h3>

            <div className={styles.storyFoot}>
              <span>{story.priority ? "JAM ROOM PICK" : "AROUND THE SCENE"}</span>
              <b>Read story ↗</b>
            </div>
          </a>
        ))}
      </div>
    </section>
  );
}
