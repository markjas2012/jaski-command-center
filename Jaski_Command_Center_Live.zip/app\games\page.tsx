import GamingRoom from "../../components/GamingRoom";

export default function GamesPage() {
  return <GamingRoom />;
}
